import * as React from 'react';
import { View, Button, Text, TouchableOpacity } from 'react-native';
import styles from "../styles";

// define the props for this component
interface Props {
  parentVal: number;
  setParentVal: (n: number) => void;
  parentFunc: (n: number) => void;
  callParentFunc: () => void;
}

// define the ref type
export interface CallableChild {
  childFunc: (n: number) => void;
  callChildFunc: () => void;
}

// call forwardRef with the generics set for the ref type and the props type
const ChildComponent = React.forwardRef<CallableChild, Props>((props, ref) => {

  //types will be know because of types of the forwardRef
  const {parentVal, setParentVal, parentFunc, callParentFunc} = props;

  // some sort of state in the child for the sake of example
  const [childVal, setChildVal] = React.useState(0);

  function childFunc(value: number) {
    alert('Hello World from Child, value is ' + value);
  }

  React.useImperativeHandle(ref, () => ({ 
    childFunc,
    callChildFunc: () => childFunc(childVal)
  }));

  return (
    <View>
      <Text>Child Value is {childVal}</Text>
      <Button title="Child --" onPress={() => setChildVal(childVal - 1)}/>
      <Button title="Child ++" onPress={() => setChildVal(childVal + 1)}/>
      <Button title="Parent -- from Child" onPress={() => setParentVal(parentVal - 1)}/>
      <Button title="Parent ++ from Child" onPress={() => setParentVal(parentVal + 1)}/>
    <TouchableOpacity style={styles.button} onPress={() => parentFunc(childVal)}>
      <Text>Call parentFunc from Child with Child Value</Text>
    </TouchableOpacity>
    <TouchableOpacity style={styles.button} onPress={callParentFunc}>
      <Text>Call parentFunc from Child with Parent Value</Text>
    </TouchableOpacity>
      
    </View>
  )
});

export default ChildComponent;