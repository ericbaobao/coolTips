import * as React from 'react';
import { Text, View, StyleSheet, TouchableOpacity, Button } from 'react-native';
import styles from './styles';

// You can import from local files
import ChildComponent, { CallableChild } from './components/ChildComponent';

export default function App() {
  // some sort of state in the parent for the sake of example
  const [parentVal, setParentVal] = React.useState(0);

  // have to declare the type for the ref
  const childRef = React.useRef<CallableChild>(null);

  function callChildFunc() {
    // expo has issues with `?.` operator in .tsx files -- can probably fix in config
    if (childRef.current) {
      childRef.current.callChildFunc();
    }
  }

  function parentFunc(value: number) {
    alert('Hello World from Parent, value is ' + value);
  }

  return (
    <View style={styles.container}>
      <Text>Parent Value is {parentVal}</Text>
      <Button title="Parent --" onPress={() => setParentVal((v) => v - 1)} />
      <Button title="Parent ++" onPress={() => setParentVal((v) => v + 1)} />
      <ChildComponent
        ref={childRef}
        parentVal={parentVal}
        setParentVal={setParentVal}
        parentFunc={parentFunc}
        callParentFunc={() => parentFunc(parentVal)}
      />
      <TouchableOpacity style={styles.button} onPress={callChildFunc}>
        <Text>Call childFunc from Parent with Child Value</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={styles.button}
        onPress={() => {
          if (childRef.current) {
            childRef.current.childFunc(parentVal);
          }
        }}>
        <Text>Call childFunc from Parent with Parent Value</Text>
      </TouchableOpacity>
    </View>
  );
}
